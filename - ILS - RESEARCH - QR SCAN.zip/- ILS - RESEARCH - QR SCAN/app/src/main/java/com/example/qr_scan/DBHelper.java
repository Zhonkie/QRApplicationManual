package com.example.qr_scan;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DBHelper extends SQLiteOpenHelper {
    private static final String DB_NAME = "users_Acc.db";
    private static final int DB_VERSION = 1;
    private static final String TABLE_NAME = "acounts";
    private static final String COL_PORTAL = "PORTAL";
    private static final String COL_EMAIL = "EMAIL";
    private static final String COL_PASSWORD = "PASSWORD";

    public DBHelper(@Nullable Context context){
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase DB) {
        //String createTable = "CREATE TABLE " + TABLE_NAME + " (" +
        //        COL_PORTAL + " TEXT PRIMARY KEY, " +
        //        COL_EMAIL + " TEXT, " + COL_PASSWORD + " TEXT)";
        //DB.execSQL(createTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase DB, int i, int i1) {
        //DB.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        //onCreate(DB);
    }
}
