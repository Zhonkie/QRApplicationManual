package com.example.qr_scan;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class QR_Scanner_PAGE extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qr_scanner_page);
    }
}