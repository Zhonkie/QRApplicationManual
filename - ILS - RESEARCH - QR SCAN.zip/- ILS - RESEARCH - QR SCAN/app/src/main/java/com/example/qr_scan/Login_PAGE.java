package com.example.qr_scan;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Login_PAGE extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_page);

        //120.29.79.180
    }
}