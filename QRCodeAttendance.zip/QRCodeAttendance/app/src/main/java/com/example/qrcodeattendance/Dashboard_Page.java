package com.example.qrcodeattendance;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class Dashboard_Page extends AppCompatActivity {

    TextView test;

    AutoCompleteTextView GRADE_CTG;
    AutoCompleteTextView SECTION_CTG;

    ArrayAdapter<String> adapterItems;
    // LIST CATEGORIES
    String[] GradeLevel_list = {"Grade 11", "Grade 12"};
    String[] Section_11 = {"ITM1101", "ABM1101", "STEM1101"};
    String[] Section_12 = {"ITM1201", "ABM1201", "STEM1201"};

    String S_GRADE;
    String S_SECTION;

    // Button for SCANNER
    FloatingActionButton SCANNER;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard_page);

        // Variable for selections of categories for the scanner
        GRADE_CTG = findViewById(R.id.GradeLevel_CATEGORIES);
        SECTION_CTG = findViewById(R.id.Section_CATEGORIES);


        // Button for Scanner
        SCANNER = findViewById(R.id.icon_SCAN);
        SCANNER.setEnabled(false);
        SCANNER.setBackgroundTintList(ContextCompat.getColorStateList(this, R.color.container_1));

        test = findViewById(R.id.test_text);

        // Setting the categories
        Display_categories(GRADE_CTG, GradeLevel_list);
        GRADE_CTG.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                S_GRADE = adapterView.getItemAtPosition(i).toString();

                switch (S_GRADE){
                    case "Grade 11":
                        Set_Section_Categories(Section_11);
                        break;

                    case "Grade 12":
                        Set_Section_Categories(Section_12);
                        break;
                }
            }
        });
    }

    public void Display_categories(AutoCompleteTextView S, String[] CT){
        adapterItems = new ArrayAdapter<String>(this, R.layout.list_section, CT);
        S.setAdapter(adapterItems);
    }

    public void Set_Section_Categories(String[] Categories){
        test.setText(S_GRADE);                       // For testing purpose only
        SECTION_CTG.setText("");                          // cleat preview item in section categories if the item selected in grade categories is change
        S_SECTION = "";

        Display_categories(SECTION_CTG, Categories);      // Setting the categories in Section
        SECTION_CTG.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                S_SECTION = SECTION_CTG.getText().toString();

                if(!S_SECTION.isEmpty()){
                    test.setText(S_GRADE + "|" + S_SECTION);
                    SCANNER.setEnabled(true);
                    SCANNER.setBackgroundTintList(ContextCompat.getColorStateList(Dashboard_Page.this, R.color.Accent));
                    SCANNER.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            toast(GRADE_CTG, SECTION_CTG, S_GRADE, S_SECTION);
                            openScanner();
                        }
                    });
                }
            }
        });
    }

    public void toast(AutoCompleteTextView GRADE, AutoCompleteTextView SECTION, String Grade, String Section){
        // For testing purpose only
        Toast.makeText(this, "GRADE:  " + Grade + "\nSECTION:  " + Section, Toast.LENGTH_LONG).show();
        Grade = "";
        Section = "";
        GRADE.setText("");
        SECTION.setText("");

        SCANNER.setEnabled(false);
        SCANNER.setBackgroundTintList(ContextCompat.getColorStateList(this, R.color.container_1));
    }

    public void openScanner(){
        //Toast.makeText(this, "LOGIN", Toast.LENGTH_LONG).show();
        Intent intent = new Intent(this, SCANNER_QR_Code_Page.class);
        startActivity(intent);
    }
}