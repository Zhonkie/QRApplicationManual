package com.example.qrcodeattendance;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.google.android.material.textfield.TextInputLayout;

public class Login_Page extends AppCompatActivity {

    TextInputLayout usernameLogin;
    TextInputLayout passwordLogin;
    private Button btn_login;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_page);

        usernameLogin = findViewById(R.id.inputEmail);
        passwordLogin = findViewById(R.id.inputPassword);
        btn_login = findViewById(R.id.btn_signin);

        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openDashboard();
            }
        });

    }

    public void openDashboard(){
        //Toast.makeText(this, "LOGIN", Toast.LENGTH_LONG).show();
        Intent intent = new Intent(this, Dashboard_Page.class);
        startActivity(intent);
    }
}